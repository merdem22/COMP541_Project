"""
Model backbones, fusion layers, and heads.
"""
