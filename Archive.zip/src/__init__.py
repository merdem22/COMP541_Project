"""
Project package marker.
"""
