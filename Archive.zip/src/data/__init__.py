"""
Data loading utilities and dataset definitions.
"""
