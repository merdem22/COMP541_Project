"""
Visualize the difference between Fixed and Learned Graph topologies.
Creates figures for presentation.
"""

import sys
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def visualize_fixed_vs_learned():
    """Create side-by-side visualization of graph topologies."""
    
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    
    # Grid parameters (showing a small 6x6 section for clarity)
    grid_size = 6
    
    # ========== No Graph ==========
    ax = axes[0]
    ax.set_title("No Graph\n(Baseline)", fontsize=14, fontweight='bold')
    
    # Draw grid nodes
    for i in range(grid_size):
        for j in range(grid_size):
            circle = plt.Circle((j, grid_size-1-i), 0.15, color='steelblue', alpha=0.7)
            ax.add_patch(circle)
    
    ax.set_xlim(-0.5, grid_size-0.5)
    ax.set_ylim(-0.5, grid_size-0.5)
    ax.set_aspect('equal')
    ax.axis('off')
    ax.text(grid_size/2-0.5, -0.8, "No connections\nbetween nodes", ha='center', fontsize=10)
    
    # ========== Fixed Graph (k=8) ==========
    ax = axes[1]
    ax.set_title("Fixed Graph (k=8)\n8 neighbors per node", fontsize=14, fontweight='bold')
    
    # Draw all 8-neighbor connections for center nodes
    for i in range(grid_size):
        for j in range(grid_size):
            y, x = grid_size-1-i, j
            # Draw edges to 8 neighbors
            for di in [-1, 0, 1]:
                for dj in [-1, 0, 1]:
                    if di == 0 and dj == 0:
                        continue
                    ni, nj = i + di, j + dj
                    if 0 <= ni < grid_size and 0 <= nj < grid_size:
                        ny, nx = grid_size-1-ni, nj
                        ax.plot([x, nx], [y, ny], 'gray', linewidth=0.5, alpha=0.3)
    
    # Draw nodes on top
    for i in range(grid_size):
        for j in range(grid_size):
            circle = plt.Circle((j, grid_size-1-i), 0.15, color='steelblue', alpha=0.7)
            ax.add_patch(circle)
    
    ax.set_xlim(-0.5, grid_size-0.5)
    ax.set_ylim(-0.5, grid_size-0.5)
    ax.set_aspect('equal')
    ax.axis('off')
    
    # Count edges
    edges_fixed = 8 * grid_size * grid_size // 2  # Approximate
    ax.text(grid_size/2-0.5, -0.8, f"~{8} edges/node\nMany redundant", ha='center', fontsize=10)
    
    # ========== Learned Graph (k=max 8) ==========
    ax = axes[2]
    ax.set_title("Learned Graph (k=max 8)\nAdaptive connections", fontsize=14, fontweight='bold')
    
    # Simulate "learned" edges - connect only meaningful pairs
    # In reality, the model learns these, but we show a conceptual example
    np.random.seed(42)
    
    # Place some "objects" (cars, pedestrians)
    objects = [(1, 2), (2, 3), (4, 1), (4, 4)]
    
    # Draw selective edges (learned to connect related nodes)
    # Reducing visible edges slightly to match the "sparser" reality (1.3 edges/node)
    learned_edges = [
        # Connections between nearby objects
        ((1, 2), (2, 2)),
        ((1, 2), (2, 3)),
        ((2, 3), (2, 2)),
        ((2, 3), (3, 3)),
        ((4, 1), (4, 2)),
        # ((4, 1), (3, 1)), # Removed to simulate sparsity
        ((4, 4), (4, 3)),
        # ((4, 4), (3, 4)), # Removed to simulate sparsity
        # Some cross-connections for context
        # ((2, 3), (4, 4)), # Removed to simulate sparsity
    ]
    
    for (i1, j1), (i2, j2) in learned_edges:
        y1, x1 = grid_size-1-i1, j1
        y2, x2 = grid_size-1-i2, j2
        ax.plot([x1, x2], [y1, y2], 'orangered', linewidth=2, alpha=0.7)
    
    # Draw nodes
    for i in range(grid_size):
        for j in range(grid_size):
            if (i, j) in objects:
                color = 'green'
                size = 0.2
            else:
                color = 'steelblue'
                size = 0.15
            circle = plt.Circle((j, grid_size-1-i), size, color=color, alpha=0.7)
            ax.add_patch(circle)
    
    ax.set_xlim(-0.5, grid_size-0.5)
    ax.set_ylim(-0.5, grid_size-0.5)
    ax.set_aspect('equal')
    ax.axis('off')
    ax.text(grid_size/2-0.5, -0.8, f"~1.3 edges/node\nOnly meaningful", ha='center', fontsize=10)
    
    # Legend
    legend_elements = [
        mpatches.Patch(color='green', label='Object (car/pedestrian)'),
        mpatches.Patch(color='steelblue', label='Empty cell'),
        plt.Line2D([0], [0], color='orangered', linewidth=2, label='Learned edge'),
        plt.Line2D([0], [0], color='gray', linewidth=1, alpha=0.5, label='Fixed edge'),
    ]
    fig.legend(handles=legend_elements, loc='lower center', ncol=4, fontsize=10)
    
    plt.tight_layout()
    plt.subplots_adjust(bottom=0.15)
    
    # Save
    output_path = Path("outputs/graph_comparison.png")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
    print(f"Saved: {output_path}")
    plt.close()


def visualize_results_bar_chart():
    """Create bar chart comparing methods."""
    
    # Results from 5-epoch comparison
    methods = ['No Graph', 'Fixed Graph\n(k=8)', 'Learned Graph\n(k=max 8)']
    recalls = [0.852, 0.816, 0.832]  # Updated 5-epoch results
    edges = [0, 8, 1.3]
    
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    
    # ========== Recall Comparison ==========
    ax = axes[0]
    colors = ['#ff7f7f', '#7fbf7f', '#7f7fff']
    bars = ax.bar(methods, recalls, color=colors, edgecolor='black', linewidth=1.5)
    
    ax.set_ylabel('Recall', fontsize=12)
    ax.set_title('Detection Recall Comparison', fontsize=14, fontweight='bold')
    ax.set_ylim(0, 1.0)
    
    # Add value labels
    for bar, val in zip(bars, recalls):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02, 
                f'{val:.1%}', ha='center', fontsize=11, fontweight='bold')
    
    # Add improvement annotations
    ax.annotate('', xy=(1, 0.777), xytext=(0, 0.711),
                arrowprops=dict(arrowstyle='->', color='green', lw=2))
    ax.text(0.5, 0.75, '+9%', fontsize=10, color='green', fontweight='bold')
    
    # Add improvement annotations
    ax.annotate('', xy=(2, 0.832), xytext=(1, 0.816),
                arrowprops=dict(arrowstyle='->', color='blue', lw=2))
    ax.text(1.5, 0.84, '+2%', fontsize=10, color='blue', fontweight='bold')
    
    ax.axhline(y=0.852, color='gray', linestyle='--', alpha=0.5, label='Baseline')
    
    # ========== Efficiency Comparison ==========
    ax = axes[1]
    
    # Edges per node
    edge_counts = [0, 8, 4]
    bars = ax.bar(methods, edge_counts, color=colors, edgecolor='black', linewidth=1.5)
    
    ax.set_ylabel('Edges per Node', fontsize=12)
    ax.set_title('Graph Efficiency Comparison', fontsize=14, fontweight='bold')
    ax.set_ylim(0, 10)
    
    for bar, val in zip(bars, edge_counts):
        label = 'N/A' if val == 0 else str(val)
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.2,
                label, ha='center', fontsize=11, fontweight='bold')
    
    # Add annotation for efficiency
    ax.annotate('50% fewer\nedges!', xy=(2, 4), xytext=(2.5, 6),
                fontsize=11, color='blue', fontweight='bold',
                arrowprops=dict(arrowstyle='->', color='blue'))
    
    plt.tight_layout()
    
    output_path = Path("outputs/results_comparison.png")
    plt.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
    print(f"Saved: {output_path}")
    plt.close()


def visualize_key_insight():
    """Create the key insight figure as bar graphs for presentation."""
    
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    
    # Data (updated with 5-epoch results)
    methods = ['Fixed Graph\n(k=8)', 'Learned Graph\n(k=max 8)']
    recalls = [0.816, 0.832]  # 5-epoch results
    edges = [80, 13]  # Thousands of edges (1.3 * 10k)
    
    # ========== Recall Bar Chart ==========
    ax = axes[0]
    colors = ['#ff6b6b', '#4ecdc4']
    bars = ax.bar(methods, recalls, color=colors, edgecolor='black', linewidth=2, width=0.6)
    
    ax.set_ylabel('Recall', fontsize=14, fontweight='bold')
    ax.set_title('Detection Performance', fontsize=16, fontweight='bold')
    ax.set_ylim(0, 1.0)
    
    # Add value labels on bars
    for bar, val in zip(bars, recalls):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02,
                f'{val:.1%}', ha='center', fontsize=14, fontweight='bold')
    
    # Add "Better!" annotation
    ax.annotate('Learned is\nBETTER!', xy=(0.5, 0.88), fontsize=12, 
                ha='center', color='green', fontweight='bold')
    
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    
    # ========== Edges Bar Chart ==========
    ax = axes[1]
    bars = ax.bar(methods, edges, color=colors, edgecolor='black', linewidth=2, width=0.6)
    
    ax.set_ylabel('Edges (thousands)', fontsize=14, fontweight='bold')
    ax.set_title('Graph Complexity', fontsize=16, fontweight='bold')
    ax.set_ylim(0, 100)
    
    # Add value labels on bars
    for bar, val in zip(bars, edges):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 2,
                f'{val}K', ha='center', fontsize=14, fontweight='bold')
    
    # Add "50% Less!" annotation with arrow
    ax.annotate('84% Fewer\nEdges!', xy=(1, 13), xytext=(1.3, 40),
                fontsize=12, ha='center', color='green', fontweight='bold',
                arrowprops=dict(arrowstyle='->', color='green', lw=2))
    
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    
    # Main title
    fig.suptitle('Key Insight: Better Performance, 84% Fewer Edges!', 
                 fontsize=18, fontweight='bold', y=1.02)
    
    plt.tight_layout()
    
    output_path = Path("outputs/key_insight.png")
    plt.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
    print(f"Saved: {output_path}")
    plt.close()


if __name__ == "__main__":
    print("Creating visualizations for presentation...")
    
    visualize_fixed_vs_learned()
    visualize_results_bar_chart()
    visualize_key_insight()
    
    print("\n✓ All visualizations saved to outputs/ folder!")
    print("\nFiles created:")
    print("  - outputs/graph_comparison.png    (Fixed vs Learned topology)")
    print("  - outputs/results_comparison.png  (Bar charts)")
    print("  - outputs/key_insight.png         (Key takeaway)")

